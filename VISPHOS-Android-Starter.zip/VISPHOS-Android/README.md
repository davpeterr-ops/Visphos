# VISPHOS — Android starter (v0.1)

VISPHOS is a free-first Android voice assistant prototype. This first build is intentionally small:
- Tap-to-speak using the Android speech-recognition activity available on the phone.
- Spoken feedback using Android Text-to-Speech.
- User-enabled Accessibility Service for back, home, scroll, and horizontal swipe gestures.
- "Next slide" / "previous slide" are implemented as horizontal swipes; apps may interpret them differently.

## Requirements
- Android Studio (free)
- JDK 17
- Android phone running Android 8.0 (API 26) or newer
- Internet may be required by the phone's speech-recognition provider. This prototype is not fully offline.

## Open and run
1. Unzip the project.
2. Open the `VISPHOS-Android` folder in Android Studio.
3. Let Gradle sync. Install any SDK 35 components Android Studio requests.
4. Connect your Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

## Enable phone controls
1. Open VISPHOS.
2. Tap **ENABLE PHONE CONTROLS**.
3. In Android Accessibility settings, select **VISPHOS device controls** and enable it.
4. Return to VISPHOS and tap **TAP TO SPEAK**.
5. Try: "scroll down", "scroll up", "go back", "go home", "next slide", "previous slide".

Android requires the user to enable Accessibility explicitly. VISPHOS does not enable it silently.

## Current limitations
- This is a starter prototype, not a finished always-listening assistant.
- Speech recognition depends on the speech service installed on the phone and may use the internet.
- No wake word, AI reasoning, app-specific navigation, screen understanding, or laptop connection yet.
- Accessibility gestures can behave differently in different apps.
- It cannot bypass Android security prompts, permissions, lock screens, or protected operations.
- Review every action before enabling broader automation. Accessibility access is powerful.

## Planned next milestones
1. Add a configurable wake phrase and foreground listening service with a clear microphone indicator.
2. Add a local command interpreter and optional free/open-source AI model.
3. Add a secure paired laptop companion for presentation control.
4. Add app-aware screen understanding with explicit user permission.
