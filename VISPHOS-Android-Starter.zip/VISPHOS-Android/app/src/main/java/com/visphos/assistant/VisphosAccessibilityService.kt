package com.visphos.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class VisphosAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* No screen contents are collected. */ }
    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun execute(action: String): Boolean {
        return when (action) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "scroll_down" -> swipe(0.78f, 0.78f, 0.78f, 0.28f)
            "scroll_up" -> swipe(0.78f, 0.28f, 0.78f, 0.78f)
            "swipe_left" -> swipe(0.82f, 0.52f, 0.18f, 0.52f)
            "swipe_right" -> swipe(0.18f, 0.52f, 0.82f, 0.52f)
            else -> false
        }
    }

    private fun swipe(startX: Float, startY: Float, endX: Float, endY: Float): Boolean {
        val metrics = resources.displayMetrics
        val path = Path().apply {
            moveTo(metrics.widthPixels * startX, metrics.heightPixels * startY)
            lineTo(metrics.widthPixels * endX, metrics.heightPixels * endY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350))
            .build()
        return dispatchGesture(gesture, null, Handler(Looper.getMainLooper()))
    }

    companion object {
        @Volatile private var instance: VisphosAccessibilityService? = null
        fun perform(action: String): Boolean = instance?.execute(action) ?: false
    }
}
