package com.visphos.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import android.view.ViewGroup
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var tts: TextToSpeech
    private val requestCodeSpeech = 42
    private val requestCodeMic = 43

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildInterface()
    }

    private fun buildInterface() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 48, 28, 32)
            setBackgroundColor(Color.rgb(10, 14, 28))
        }

        val title = TextView(this).apply {
            text = "VISPHOS"
            textSize = 34f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "YOUR VOICE. YOUR DEVICES."
            textSize = 12f
            letterSpacing = 0.18f
            setTextColor(Color.rgb(120, 180, 255))
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Ready when you are."
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 48, 0, 20)
        }
        transcript = TextView(this).apply {
            text = "Try: “scroll down”, “go back”, “next slide”"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(8, 12, 8, 32)
        }
        val listen = Button(this).apply {
            text = "TAP TO SPEAK"
            textSize = 16f
            setOnClickListener { startListening() }
        }
        val accessibility = Button(this).apply {
            text = "ENABLE PHONE CONTROLS"
            setOnClickListener {
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        val settings = Button(this).apply {
            text = "OPEN PHONE SETTINGS"
            setOnClickListener { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
        }

        page.addView(title, matchWrap())
        page.addView(subtitle, matchWrap())
        page.addView(status, matchWrap())
        page.addView(transcript, matchWrap())
        page.addView(listen, matchWrap())
        page.addView(accessibility, matchWrap())
        page.addView(settings, matchWrap())
        setContentView(page)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), requestCodeMic)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak a VISPHOS command")
        }
        try {
            startActivityForResult(intent, requestCodeSpeech)
        } catch (_: Exception) {
            update("Speech recognition is unavailable on this phone.")
        }
    }

    @Deprecated("Uses activity result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCodeSpeech && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) handleCommand(spoken)
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale.getDefault())
        transcript.text = "You said: “$raw”"

        val action = when {
            "scroll down" in command || "move down" in command -> "scroll_down"
            "scroll up" in command || "move up" in command -> "scroll_up"
            "next slide" in command || "next page" in command || "go next" in command -> "swipe_left"
            "previous slide" in command || "previous page" in command || "go back a slide" in command -> "swipe_right"
            command == "go back" || "go back" in command -> "back"
            "go home" in command || "home screen" in command -> "home"
            "open settings" in command || "phone settings" in command -> "settings"
            else -> null
        }

        if (action == null) {
            update("I heard you, but that command isn't available yet.")
            return
        }

        when (action) {
            "settings" -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                update("Opening phone settings.")
            }
            else -> {
                val success = VisphosAccessibilityService.perform(action)
                if (success) {
                    val response = when (action) {
                        "scroll_down" -> "Scrolling down."
                        "scroll_up" -> "Scrolling up."
                        "swipe_left" -> "Moving to the next page or slide."
                        "swipe_right" -> "Moving to the previous page or slide."
                        "back" -> "Going back."
                        "home" -> "Going to the home screen."
                        else -> "Done."
                    }
                    update(response)
                } else {
                    update("Phone controls are not enabled yet. Tap Enable Phone Controls and turn on VISPHOS.")
                }
            }
        }
    }

    private fun update(message: String) {
        status.text = message
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "visphos_reply")
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) tts.language = Locale.getDefault()
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
